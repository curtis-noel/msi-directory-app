# Generic/static pages
class BoilerplateController < ApplicationController
  def terms
  end
end

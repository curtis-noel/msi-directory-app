# PAGE CONTROLLER HELPER FUNCTIONS
module PageSharedFunctions
end
